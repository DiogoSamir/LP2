﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtLadA.Clear();
            txtLadB.Clear();
            txtLadC.Clear();
            txtTipo.Text = "";
        }

        private void btnTriType_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtLadA.Text, out double a) && double.TryParse(txtLadB.Text, out double b) && double.TryParse(txtLadC.Text, out double c))
            {
                if (Math.Abs(b - c) < a && a < b + c && Math.Abs(a - c) < b && b < a + c && Math.Abs(a - b) < c && c < a + b)
                {
                    if (a == b && b == c) { txtTipo.Text = "Equilátero"; }
                    else if (a == b || a == c || b == c) { txtTipo.Text = "Isósceles"; }
                    else { txtTipo.Text = "Escaleno"; }
                }
                else
                {
                    MessageBox.Show("Os valores inseridos não correspondem a um triângulo", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Valores inválidos!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
