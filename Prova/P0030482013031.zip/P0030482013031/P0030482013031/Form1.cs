﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace P0030482013031
{
    public partial class FrmProva : Form
    {
        public FrmProva()
        {
            InitializeComponent();
        }

        private void btnVerif_Click(object sender, EventArgs e)
        
        {
            double[,] matriz = new double[1, 4];
            listValores.Items.Clear();
            bool aux;
            double resultMes = 0;
            double resultTotal = 0;
            for (int i = 0; i < 1; i++)
            {
                resultMes = 0;
                for (int h = 0; h < 4; h++)
                {
                    do
                    {
                        aux = double.TryParse(Interaction.InputBox("Digite os valores da semana " + (h + 1), "Digite os valores"), out matriz[i, h]);
                    } while (aux == false);
                    listValores.Items.Add("Total do Mês" + (i + 1) + ": Semana " + (h + 1) + " " + matriz[i, h].ToString("C2"));
                    resultMes += matriz[i, h];
                }
                listValores.Items.Add(">>Total do Mês" + resultMes.ToString("C2"));
                listValores.Items.Add("--------------------------------\n");
                resultTotal += resultMes;
            }
            listValores.Items.Add(">>Total Geral: " + resultTotal.ToString("C2"));
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
