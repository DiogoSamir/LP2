﻿
namespace P0030482013031
{
    partial class FrmProva
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.listValores = new System.Windows.Forms.ListBox();
            this.btnVerif = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // listValores
            // 
            this.listValores.FormattingEnabled = true;
            this.listValores.Location = new System.Drawing.Point(316, 48);
            this.listValores.Name = "listValores";
            this.listValores.Size = new System.Drawing.Size(304, 303);
            this.listValores.TabIndex = 4;
            // 
            // btnVerif
            // 
            this.btnVerif.Location = new System.Drawing.Point(109, 163);
            this.btnVerif.Name = "btnVerif";
            this.btnVerif.Size = new System.Drawing.Size(129, 65);
            this.btnVerif.TabIndex = 1;
            this.btnVerif.Text = "Verificar";
            this.btnVerif.UseVisualStyleBackColor = true;
            this.btnVerif.Click += new System.EventHandler(this.btnVerif_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(134, 234);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(75, 23);
            this.btnSair.TabIndex = 5;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // FrmProva
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnVerif);
            this.Controls.Add(this.listValores);
            this.Name = "FrmProva";
            this.Text = "Prova";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox listValores;
        private System.Windows.Forms.Button btnVerif;
        private System.Windows.Forms.Button btnSair;
    }
}

