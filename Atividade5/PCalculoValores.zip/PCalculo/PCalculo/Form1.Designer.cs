﻿namespace PCalculo
{
    partial class CalculoSalario
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtSalLiq = new System.Windows.Forms.TextBox();
            this.txtSalFam = new System.Windows.Forms.TextBox();
            this.txtDescIRPF = new System.Windows.Forms.TextBox();
            this.txtDescINSS = new System.Windows.Forms.TextBox();
            this.txtAliqIRPF = new System.Windows.Forms.TextBox();
            this.txtAliqINSS = new System.Windows.Forms.TextBox();
            this.lblDIRPF = new System.Windows.Forms.Label();
            this.lblDINSS = new System.Windows.Forms.Label();
            this.lblSalLiq = new System.Windows.Forms.Label();
            this.lblSalFam = new System.Windows.Forms.Label();
            this.lblAIRPF = new System.Windows.Forms.Label();
            this.lblAInss = new System.Windows.Forms.Label();
            this.ValDados = new System.Windows.Forms.Label();
            this.btnSair = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnCalc = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cboxCasado = new System.Windows.Forms.CheckBox();
            this.gBoxSexo = new System.Windows.Forms.GroupBox();
            this.btnMasculino = new System.Windows.Forms.RadioButton();
            this.btnFeminino = new System.Windows.Forms.RadioButton();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtSalario = new System.Windows.Forms.MaskedTextBox();
            this.cboxFilhos = new System.Windows.Forms.ComboBox();
            this.lbl3 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.gBoxSexo.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtSalLiq
            // 
            this.txtSalLiq.Enabled = false;
            this.txtSalLiq.Location = new System.Drawing.Point(153, 310);
            this.txtSalLiq.Name = "txtSalLiq";
            this.txtSalLiq.Size = new System.Drawing.Size(100, 20);
            this.txtSalLiq.TabIndex = 47;
            // 
            // txtSalFam
            // 
            this.txtSalFam.Enabled = false;
            this.txtSalFam.Location = new System.Drawing.Point(153, 338);
            this.txtSalFam.Name = "txtSalFam";
            this.txtSalFam.Size = new System.Drawing.Size(100, 20);
            this.txtSalFam.TabIndex = 46;
            // 
            // txtDescIRPF
            // 
            this.txtDescIRPF.Enabled = false;
            this.txtDescIRPF.Location = new System.Drawing.Point(456, 272);
            this.txtDescIRPF.Name = "txtDescIRPF";
            this.txtDescIRPF.Size = new System.Drawing.Size(100, 20);
            this.txtDescIRPF.TabIndex = 45;
            // 
            // txtDescINSS
            // 
            this.txtDescINSS.Enabled = false;
            this.txtDescINSS.Location = new System.Drawing.Point(456, 242);
            this.txtDescINSS.Name = "txtDescINSS";
            this.txtDescINSS.Size = new System.Drawing.Size(100, 20);
            this.txtDescINSS.TabIndex = 44;
            // 
            // txtAliqIRPF
            // 
            this.txtAliqIRPF.Enabled = false;
            this.txtAliqIRPF.Location = new System.Drawing.Point(206, 276);
            this.txtAliqIRPF.Name = "txtAliqIRPF";
            this.txtAliqIRPF.Size = new System.Drawing.Size(100, 20);
            this.txtAliqIRPF.TabIndex = 43;
            // 
            // txtAliqINSS
            // 
            this.txtAliqINSS.Enabled = false;
            this.txtAliqINSS.Location = new System.Drawing.Point(206, 246);
            this.txtAliqINSS.Name = "txtAliqINSS";
            this.txtAliqINSS.Size = new System.Drawing.Size(100, 20);
            this.txtAliqINSS.TabIndex = 42;
            // 
            // lblDIRPF
            // 
            this.lblDIRPF.AutoSize = true;
            this.lblDIRPF.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDIRPF.Location = new System.Drawing.Point(358, 277);
            this.lblDIRPF.Name = "lblDIRPF";
            this.lblDIRPF.Size = new System.Drawing.Size(92, 15);
            this.lblDIRPF.TabIndex = 41;
            this.lblDIRPF.Text = "Desconto IRPF:";
            // 
            // lblDINSS
            // 
            this.lblDINSS.AutoSize = true;
            this.lblDINSS.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDINSS.Location = new System.Drawing.Point(357, 247);
            this.lblDINSS.Name = "lblDINSS";
            this.lblDINSS.Size = new System.Drawing.Size(93, 15);
            this.lblDINSS.TabIndex = 40;
            this.lblDINSS.Text = "Desconto INSS:";
            // 
            // lblSalLiq
            // 
            this.lblSalLiq.AutoSize = true;
            this.lblSalLiq.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalLiq.Location = new System.Drawing.Point(33, 311);
            this.lblSalLiq.Name = "lblSalLiq";
            this.lblSalLiq.Size = new System.Drawing.Size(93, 15);
            this.lblSalLiq.TabIndex = 39;
            this.lblSalLiq.Text = "Salário Liquido:";
            // 
            // lblSalFam
            // 
            this.lblSalFam.AutoSize = true;
            this.lblSalFam.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalFam.Location = new System.Drawing.Point(33, 343);
            this.lblSalFam.Name = "lblSalFam";
            this.lblSalFam.Size = new System.Drawing.Size(93, 15);
            this.lblSalFam.TabIndex = 38;
            this.lblSalFam.Text = "Salário Família:";
            // 
            // lblAIRPF
            // 
            this.lblAIRPF.AutoSize = true;
            this.lblAIRPF.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAIRPF.Location = new System.Drawing.Point(116, 277);
            this.lblAIRPF.Name = "lblAIRPF";
            this.lblAIRPF.Size = new System.Drawing.Size(84, 15);
            this.lblAIRPF.TabIndex = 37;
            this.lblAIRPF.Text = "Alíquota IRPF:";
            // 
            // lblAInss
            // 
            this.lblAInss.AutoSize = true;
            this.lblAInss.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAInss.Location = new System.Drawing.Point(115, 247);
            this.lblAInss.Name = "lblAInss";
            this.lblAInss.Size = new System.Drawing.Size(85, 15);
            this.lblAInss.TabIndex = 36;
            this.lblAInss.Text = "Alíquota INSS:";
            // 
            // ValDados
            // 
            this.ValDados.AutoSize = true;
            this.ValDados.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ValDados.Location = new System.Drawing.Point(12, 143);
            this.ValDados.Name = "ValDados";
            this.ValDados.Size = new System.Drawing.Size(100, 15);
            this.ValDados.TabIndex = 35;
            this.ValDados.Text = "Validação Dados";
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(534, 354);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(75, 23);
            this.btnSair.TabIndex = 34;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click_1);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(431, 354);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(75, 23);
            this.btnLimpar.TabIndex = 33;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click_1);
            // 
            // btnCalc
            // 
            this.btnCalc.Location = new System.Drawing.Point(206, 134);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(100, 34);
            this.btnCalc.TabIndex = 32;
            this.btnCalc.Text = "Calcular";
            this.btnCalc.UseVisualStyleBackColor = true;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.cboxCasado);
            this.panel1.Location = new System.Drawing.Point(409, 123);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 28);
            this.panel1.TabIndex = 31;
            // 
            // cboxCasado
            // 
            this.cboxCasado.AutoSize = true;
            this.cboxCasado.Location = new System.Drawing.Point(35, 8);
            this.cboxCasado.Name = "cboxCasado";
            this.cboxCasado.Size = new System.Drawing.Size(62, 17);
            this.cboxCasado.TabIndex = 0;
            this.cboxCasado.Text = "Casado";
            this.cboxCasado.UseVisualStyleBackColor = true;
            // 
            // gBoxSexo
            // 
            this.gBoxSexo.Controls.Add(this.btnMasculino);
            this.gBoxSexo.Controls.Add(this.btnFeminino);
            this.gBoxSexo.Location = new System.Drawing.Point(409, 17);
            this.gBoxSexo.Name = "gBoxSexo";
            this.gBoxSexo.Size = new System.Drawing.Size(200, 100);
            this.gBoxSexo.TabIndex = 30;
            this.gBoxSexo.TabStop = false;
            this.gBoxSexo.Text = "Sexo";
            // 
            // btnMasculino
            // 
            this.btnMasculino.AutoSize = true;
            this.btnMasculino.Location = new System.Drawing.Point(35, 71);
            this.btnMasculino.Name = "btnMasculino";
            this.btnMasculino.Size = new System.Drawing.Size(73, 17);
            this.btnMasculino.TabIndex = 1;
            this.btnMasculino.TabStop = true;
            this.btnMasculino.Text = "Masculino";
            this.btnMasculino.UseVisualStyleBackColor = true;
            // 
            // btnFeminino
            // 
            this.btnFeminino.AutoSize = true;
            this.btnFeminino.Location = new System.Drawing.Point(35, 34);
            this.btnFeminino.Name = "btnFeminino";
            this.btnFeminino.Size = new System.Drawing.Size(67, 17);
            this.btnFeminino.TabIndex = 0;
            this.btnFeminino.TabStop = true;
            this.btnFeminino.Text = "Feminino";
            this.btnFeminino.UseVisualStyleBackColor = true;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(206, 44);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 20);
            this.txtNome.TabIndex = 29;
            // 
            // txtSalario
            // 
            this.txtSalario.Location = new System.Drawing.Point(206, 70);
            this.txtSalario.Mask = "00000.00";
            this.txtSalario.Name = "txtSalario";
            this.txtSalario.Size = new System.Drawing.Size(100, 20);
            this.txtSalario.TabIndex = 28;
            this.txtSalario.ValidatingType = typeof(int);
            // 
            // cboxFilhos
            // 
            this.cboxFilhos.FormattingEnabled = true;
            this.cboxFilhos.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.cboxFilhos.Location = new System.Drawing.Point(206, 96);
            this.cboxFilhos.Name = "cboxFilhos";
            this.cboxFilhos.Size = new System.Drawing.Size(100, 21);
            this.cboxFilhos.TabIndex = 27;
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3.Location = new System.Drawing.Point(150, 102);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(50, 15);
            this.lbl3.TabIndex = 26;
            this.lbl3.Text = "Filhos:";
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2.Location = new System.Drawing.Point(105, 70);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(95, 15);
            this.lbl2.TabIndex = 25;
            this.lbl2.Text = "Salário Bruto:";
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.Location = new System.Drawing.Point(55, 45);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(149, 15);
            this.lbl1.TabIndex = 24;
            this.lbl1.Text = "Nome do Funcionário:";
            // 
            // CalculoSalario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtSalLiq);
            this.Controls.Add(this.txtSalFam);
            this.Controls.Add(this.txtDescIRPF);
            this.Controls.Add(this.txtDescINSS);
            this.Controls.Add(this.txtAliqIRPF);
            this.Controls.Add(this.txtAliqINSS);
            this.Controls.Add(this.lblDIRPF);
            this.Controls.Add(this.lblDINSS);
            this.Controls.Add(this.lblSalLiq);
            this.Controls.Add(this.lblSalFam);
            this.Controls.Add(this.lblAIRPF);
            this.Controls.Add(this.lblAInss);
            this.Controls.Add(this.ValDados);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.gBoxSexo);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtSalario);
            this.Controls.Add(this.cboxFilhos);
            this.Controls.Add(this.lbl3);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.lbl1);
            this.Name = "CalculoSalario";
            this.Text = "CalculoSalario";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.gBoxSexo.ResumeLayout(false);
            this.gBoxSexo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtSalLiq;
        private System.Windows.Forms.TextBox txtSalFam;
        private System.Windows.Forms.TextBox txtDescIRPF;
        private System.Windows.Forms.TextBox txtDescINSS;
        private System.Windows.Forms.TextBox txtAliqIRPF;
        private System.Windows.Forms.TextBox txtAliqINSS;
        private System.Windows.Forms.Label lblDIRPF;
        private System.Windows.Forms.Label lblDINSS;
        private System.Windows.Forms.Label lblSalLiq;
        private System.Windows.Forms.Label lblSalFam;
        private System.Windows.Forms.Label lblAIRPF;
        private System.Windows.Forms.Label lblAInss;
        private System.Windows.Forms.Label ValDados;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox cboxCasado;
        private System.Windows.Forms.GroupBox gBoxSexo;
        private System.Windows.Forms.RadioButton btnMasculino;
        private System.Windows.Forms.RadioButton btnFeminino;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.MaskedTextBox txtSalario;
        private System.Windows.Forms.ComboBox cboxFilhos;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl1;
    }
}

