﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalculo
{
    public partial class CalculoSalario : Form

    {
        double SalBruto, Filhos, AliqINSS, AliqIRPF, SalFam, DescINSS, DescIRPF, SalLiq;
        string EstCivil, Sexo;

        private void btnSair_Click_1(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click_1(object sender, EventArgs e)
        {
               
            txtNome.Clear();
            txtAliqINSS.Clear();
            txtAliqIRPF.Clear();
            txtDescINSS.Clear();
            txtDescIRPF.Clear();
            txtSalFam.Clear();
            txtSalLiq.Clear();
            txtSalario.Clear();
            cboxFilhos.Text = "";
            cboxCasado.Enabled.ToString();
            btnFeminino.Enabled.ToString();
            btnMasculino.Enabled.ToString();
            ValDados.Text = "";
            
        }

        public CalculoSalario()
        {
            InitializeComponent();
        }

        private void CalculoSalario_Load(object sender, EventArgs e)
        {

        }


        private void btnCalc_Click(object sender, EventArgs e)
        {
            txtAliqINSS.Clear();
            txtAliqIRPF.Clear();
            txtDescINSS.Clear();
            txtDescIRPF.Clear();
            txtSalFam.Clear();
            txtSalLiq.Clear();
            Sexo = "";
            EstCivil = "";

            if (btnFeminino.Checked)
                Sexo = "Feminino";
            else
                Sexo = "Masculino";
            if (cboxCasado.Checked)
                EstCivil = "Casado";
            else
                EstCivil = "Solteiro";

            if ((txtNome.Text != "") && (txtSalario.Text != "") && (cboxFilhos.Text != ""))
            {
                SalBruto = Convert.ToDouble(txtSalario.Text);
                Filhos = Convert.ToDouble(cboxFilhos.Text);
                AliqINSS = 0;
                AliqIRPF = 0;
                SalFam = 0;
                DescINSS = 0;
                DescIRPF = 0;
                if (SalBruto > 2801.56)
                {
                    AliqIRPF = 0.275;
                    AliqINSS = 0;
                    SalFam = 0;
                    DescINSS = 308.17;
                }
                if (SalBruto <= 2801.56)
                {
                    if (SalBruto <= 2512.08)
                        AliqIRPF = 0.15;
                    else
                        AliqIRPF = 0.275;
                    AliqINSS = 0.11;
                }
                if (SalBruto <= 1400.77)
                {
                    if (SalBruto <= 1257.12)
                        AliqIRPF = 0;
                    else
                        AliqIRPF = 0.15;
                    AliqINSS = 0.09;
                }
                if (SalBruto <= 1050)
                    AliqINSS = 0.0865;

                if (SalBruto < 800.48)
                {
                    if (SalBruto < 654.62)
                    {
                        if (SalBruto < 435.53)
                            SalFam = 22.33 * Filhos;
                        else
                            SalFam = 15.74 * Filhos;
                    }
                    AliqINSS = 0.0765;
                }

                if (DescINSS == 0)
                    DescINSS = SalBruto * AliqINSS;
                DescIRPF = SalBruto * AliqIRPF;
                SalLiq = (SalBruto - DescINSS - DescIRPF + SalFam);

                txtAliqINSS.Text = (AliqINSS * 100 + " %");
                txtAliqIRPF.Text = (AliqIRPF * 100 + " %");
                txtSalFam.Text = ("R$ " + SalFam);
                txtDescINSS.Text = ("R$ " + DescINSS);
                txtDescIRPF.Text = ("R$ " + DescIRPF);
                txtSalLiq.Text = ("R$ " + SalLiq);
                ValDados.Text = ("Funcionário: " + txtNome.Text + "\nSexo: " + Sexo + "\nFilhos: " + cboxFilhos.Text +
                "\nEstado Civil: " + EstCivil);

            }
            else
                MessageBox.Show("Os campos devem estar todos preenchidos!");
        }
    }
}