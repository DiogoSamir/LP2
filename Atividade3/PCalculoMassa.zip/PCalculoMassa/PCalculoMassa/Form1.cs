﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalculoMassa
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtAlt.Clear();
            txtAval.Clear();
            txtPeso.Clear();
            radioM.Checked = true;
            radioF.Checked = false;
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            if (radioM.Checked)
            {
                Calculate("M");
            }
            else
            {
                Calculate("F");
            }
        }

        private void Calculate(string sexo)
        {
            double PesoIdeal;
            string Avaliação = "Você está com o peso ideal";

            if ((radioF.Checked || radioM.Checked) && double.TryParse(txtAlt.Text, out double valor1) && double.TryParse(txtPeso.Text, out double valor2))
            {
                switch (sexo)
                {
                    case "M":
                        PesoIdeal = (72.7 * valor1) - 58;
                        PesoIdeal = Math.Round(PesoIdeal, 3);
                        if (valor2 < PesoIdeal) { Avaliação = "Coma bastante massas e doces"; }
                        if (valor2 > PesoIdeal) { Avaliação = "Regime obrigatório já"; }

                        txtAval.Text = Avaliação;
                        break;
                    case "F":
                        PesoIdeal = (62.1 * valor1) - 44.7;
                        PesoIdeal = Math.Round(PesoIdeal, 3);
                        if (valor2 < PesoIdeal) { Avaliação = "Coma bastante massas e doces"; }
                        if (valor2 > PesoIdeal) { Avaliação = "Regime obrigatório já"; }

                        txtAval.Text = Avaliação;
                        break;
                }
            }
        }
    }
}
