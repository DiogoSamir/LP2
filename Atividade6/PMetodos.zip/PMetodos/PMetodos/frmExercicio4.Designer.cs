﻿namespace PMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnNum = new System.Windows.Forms.Button();
            this.btnPosBranco = new System.Windows.Forms.Button();
            this.btnAlfab = new System.Windows.Forms.Button();
            this.rchTxt = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnNum
            // 
            this.btnNum.Location = new System.Drawing.Point(82, 274);
            this.btnNum.Name = "btnNum";
            this.btnNum.Size = new System.Drawing.Size(115, 41);
            this.btnNum.TabIndex = 0;
            this.btnNum.Text = "Númericos";
            this.btnNum.UseVisualStyleBackColor = true;
            this.btnNum.Click += new System.EventHandler(this.btnNum_Click);
            // 
            // btnPosBranco
            // 
            this.btnPosBranco.Location = new System.Drawing.Point(276, 274);
            this.btnPosBranco.Name = "btnPosBranco";
            this.btnPosBranco.Size = new System.Drawing.Size(131, 41);
            this.btnPosBranco.TabIndex = 1;
            this.btnPosBranco.Text = "Posição Primeiro Espaço em Branco";
            this.btnPosBranco.UseVisualStyleBackColor = true;
            this.btnPosBranco.Click += new System.EventHandler(this.btnPosBranco_Click);
            // 
            // btnAlfab
            // 
            this.btnAlfab.Location = new System.Drawing.Point(477, 274);
            this.btnAlfab.Name = "btnAlfab";
            this.btnAlfab.Size = new System.Drawing.Size(121, 41);
            this.btnAlfab.TabIndex = 2;
            this.btnAlfab.Text = "Alfabéticos";
            this.btnAlfab.UseVisualStyleBackColor = true;
            this.btnAlfab.Click += new System.EventHandler(this.btnAlfab_Click);
            // 
            // rchTxt
            // 
            this.rchTxt.Location = new System.Drawing.Point(82, 94);
            this.rchTxt.Name = "rchTxt";
            this.rchTxt.Size = new System.Drawing.Size(516, 96);
            this.rchTxt.TabIndex = 3;
            this.rchTxt.Text = "";
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.rchTxt);
            this.Controls.Add(this.btnAlfab);
            this.Controls.Add(this.btnPosBranco);
            this.Controls.Add(this.btnNum);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnNum;
        private System.Windows.Forms.Button btnPosBranco;
        private System.Windows.Forms.Button btnAlfab;
        private System.Windows.Forms.RichTextBox rchTxt;
    }
}