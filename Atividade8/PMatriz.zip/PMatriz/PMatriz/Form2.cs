﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatriz
{
    public partial class frm2 : Form
    {
        public frm2()
        {
            InitializeComponent();
        }

        private void btnExec_Click(object sender, EventArgs e)
        {
            string[] nome = new string[1];
            int[] qtdChar = new int[1];
            string aux = "";

            for (int i = 0; i < nome.Length; i++)
            {
                aux = Interaction.InputBox("Digite o nome completo:");

                if (aux != "")
                {
                    nome[i] = aux;
                    aux = nome[i].Replace(" ", "");
                    qtdChar[i] = aux.Length;

                    listBox1.Items.Add("O nome " + nome[i] + " tem " + qtdChar[i] + " caracteres.");
                }
                else
                {
                    MessageBox.Show("Nome não pode estar em branco!");
                    i--;
                }
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
