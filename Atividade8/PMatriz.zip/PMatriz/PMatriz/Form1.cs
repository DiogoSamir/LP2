﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatriz
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExer1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];

            string aux = "";
            for (var i = 0; i < vetor.Length; i++)
            {
                aux = Interaction.InputBox("Entre com o valor: " + (i + 1).ToString(),
                    "Entrada de Dados");
                if (!int.TryParse(aux, out vetor[i]))
                {
                    MessageBox.Show("Número inválido!");
                    i--;
                }
            }

            aux = "";

            for (var i = vetor.Length - 1; i >= 0; i--)
                aux += "\n" + vetor[i].ToString();

            MessageBox.Show(aux);

        }

        private void btnExer2_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];

            string aux = "";
            for (var i = 0; i < vetor.Length; i++)
            {
                aux = Interaction.InputBox("Entre com o valor: " + (i + 1).ToString(),
                    "Entrada de Dados");
                if (!int.TryParse(aux, out vetor[i]))
                {
                    MessageBox.Show("Número inválido!");
                    i--;
                }
            }

            Array.Reverse(vetor);

            aux = "";

            for (int i = vetor.Length - 1; i >= 0; i--)
            {
                aux += vetor[i].ToString() + "\n";
            }

            MessageBox.Show(aux);
        }

        private void btnExer3_Click(object sender, EventArgs e)
        {
            double[] qtd = new double[10];
            double[] val = new double[10];

            bool qtdCerta = false;

            string auxiliar = "";

            for (int i = 0; i < qtd.Length; i++)
            {
                if (!qtdCerta)
                {
                    auxiliar = Interaction.InputBox("Digite a quantidade do produto " + (i + 1).ToString() + ": ");

                    if (!(double.TryParse(auxiliar, out qtd[i])))
                    {
                        MessageBox.Show("Quantidade inválida!");
                        i--;
                    }
                    else
                    {
                        qtdCerta = true;
                    }
                }

                auxiliar = Interaction.InputBox("Digite o valor do produto " + (i + 1).ToString() + ": ");

                if (!(double.TryParse(auxiliar, out val[i])))
                {
                    MessageBox.Show("Valor inválido!");
                    i--;
                }
                else
                {
                    qtdCerta = false;
                }
            }

            double faturamento = 0;

            for (int i = 0; i < qtd.Length; i++)
            {
                faturamento += qtd[i] * val[i];
            }

            MessageBox.Show("Faturamento do mês: R$ " + faturamento.ToString("N2"));
        }

        private void btnExer4_Click(object sender, EventArgs e)
        {
            string[] Alunos = { "Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo", "Jose", "Nelma", "Tobby" };

            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            for (I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
            }
            MessageBox.Show("O total é: " + Total.ToString());
        }

        private void btnExer5_Click(object sender, EventArgs e)
        {
            ArrayList arra = new ArrayList();

            arra.Add("Ana");
            arra.Add("André");
            arra.Add("Débora");
            arra.Add("Fátima");
            arra.Add("João");
            arra.Add("Janete");
            arra.Add("Otávio");
            arra.Add("Marcelo");
            arra.Add("Pedro");
            arra.Add("Thais");

            arra.Remove("Otávio");

            string text = "";

            for (int i = 0; i < arra.Count; i++)
            {
                text += arra[i] + "\n";
            }

            MessageBox.Show(text);
        }

        private void btnExer6_Click(object sender, EventArgs e)
        {
            double[,] nota = new double[20, 3];

            string aux = "";

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    aux = Interaction.InputBox("Digite a nota " + (j + 1).ToString() + " do aluno " + (i + 1).ToString());

                    if (!(double.TryParse(aux, out nota[i, j])))
                    {
                        MessageBox.Show("Valor de nota inválido!");
                        j--;
                    }
                }
            }

            aux = "";

            for (int i = 0; i < 20; i++)
            {
                aux += "Aluno " + (i + 1).ToString() + ": média " + ((nota[i, 0] + nota[i, 1] + nota[i, 2]) / 3).ToString("N2") + "\n";
            }

            MessageBox.Show(aux);
        }

        private void btnExer7_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["frm2"];

            if (fc != null)
            {
                fc.Close();
            }

            frm2 frm = new frm2();
            frm.Show();
        }
    }
}
