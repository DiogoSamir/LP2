﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            double SalBruto = 0;
            double SalLiq = Convert.ToDouble(txtSalario.Text);
            double B, C, D;
            double Prod = Convert.ToDouble(txtProd.Text);
            double Grat = Convert.ToDouble(txtGratif.Text);
            //MessageBox.Show("Test"+Prod);
            if (Prod >= 100)
            {
                if (Prod >= 120)
                {
                    if (Prod >= 150)
                    {
                        B = 1;
                        C = 1;
                        D = 1;
                    }
                    else
                    {
                        B = 1;
                        C = 1;
                        D = 0;
                    }
                }
                else
                {
                    B = 1;
                    C = 0;
                    D = 0;
                }
            }
            else
            {
                B = 0;
                C = 0;
                D = 0;
            }

            SalBruto = SalLiq + (SalLiq * (0.05 * B + 0.1 * C + 0.1 * D)) + Grat;
            //MessageBox.Show("teste" + SalBruto);

            if (SalBruto > 7000)
            {
                if (Prod < 150 || Grat <= 0)
                {
                    MessageBox.Show("Salário Acima do Teto\n " + SalBruto);
                }
                else
                {
                    MessageBox.Show("Nome do funcionário: " + txtNome.Text.ToString() + "\n" + "Salário do Funcionário: " + SalLiq + "\n" +
                        "Cargo: " + txtCargo.Text.ToString() + "\n" +
                        "Inscrição: " + txtNumInscric.Text.ToString() + "\n" + "Salario Bruto: " + SalBruto);
                }
            }
            else
            {
                MessageBox.Show("Nome do funcionário: " + txtNome.Text.ToString() + "\n" + "Salário do Funcionário: " + SalLiq + "\n" +
                        "Cargo: " + txtCargo.Text.ToString() + "\n" +
                        "Inscrição: " + txtNumInscric.Text.ToString() + "\n" + "Salario Bruto: " + SalBruto); ;
            }
        }

        private void btnVolt_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
    
}
