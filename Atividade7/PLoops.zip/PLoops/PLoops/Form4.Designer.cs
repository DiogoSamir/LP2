﻿namespace PLoops
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnVerif = new System.Windows.Forms.Button();
            this.btnVolt = new System.Windows.Forms.Button();
            this.txtPalindro = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnVerif
            // 
            this.btnVerif.AccessibleDescription = "";
            this.btnVerif.Location = new System.Drawing.Point(220, 113);
            this.btnVerif.Name = "btnVerif";
            this.btnVerif.Size = new System.Drawing.Size(75, 54);
            this.btnVerif.TabIndex = 0;
            this.btnVerif.Text = "Verifica se é Palíndromo";
            this.btnVerif.UseVisualStyleBackColor = true;
            this.btnVerif.Click += new System.EventHandler(this.btnVerif_Click);
            // 
            // btnVolt
            // 
            this.btnVolt.Location = new System.Drawing.Point(355, 113);
            this.btnVolt.Name = "btnVolt";
            this.btnVolt.Size = new System.Drawing.Size(75, 54);
            this.btnVolt.TabIndex = 1;
            this.btnVolt.Text = "Voltar";
            this.btnVolt.UseVisualStyleBackColor = true;
            this.btnVolt.Click += new System.EventHandler(this.btnVolt_Click);
            // 
            // txtPalindro
            // 
            this.txtPalindro.Location = new System.Drawing.Point(220, 64);
            this.txtPalindro.Name = "txtPalindro";
            this.txtPalindro.Size = new System.Drawing.Size(210, 20);
            this.txtPalindro.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(259, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "Digite uma frase";
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtPalindro);
            this.Controls.Add(this.btnVolt);
            this.Controls.Add(this.btnVerif);
            this.Name = "Form4";
            this.Text = "Form4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnVerif;
        private System.Windows.Forms.Button btnVolt;
        private System.Windows.Forms.TextBox txtPalindro;
        private System.Windows.Forms.Label label1;
    }
}