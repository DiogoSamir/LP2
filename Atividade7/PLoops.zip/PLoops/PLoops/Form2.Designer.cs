﻿namespace PLoops
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchTxt1 = new System.Windows.Forms.RichTextBox();
            this.btnContBranco = new System.Windows.Forms.Button();
            this.btnContR = new System.Windows.Forms.Button();
            this.btnContPar = new System.Windows.Forms.Button();
            this.btnVoltar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchTxt1
            // 
            this.rchTxt1.Location = new System.Drawing.Point(224, 105);
            this.rchTxt1.MaxLength = 100;
            this.rchTxt1.Name = "rchTxt1";
            this.rchTxt1.Size = new System.Drawing.Size(279, 96);
            this.rchTxt1.TabIndex = 0;
            this.rchTxt1.Text = "";
            // 
            // btnContBranco
            // 
            this.btnContBranco.Location = new System.Drawing.Point(152, 255);
            this.btnContBranco.Name = "btnContBranco";
            this.btnContBranco.Size = new System.Drawing.Size(75, 54);
            this.btnContBranco.TabIndex = 1;
            this.btnContBranco.Text = "Conta Espaço em Branco";
            this.btnContBranco.UseVisualStyleBackColor = true;
            this.btnContBranco.Click += new System.EventHandler(this.btnContBranco_Click);
            // 
            // btnContR
            // 
            this.btnContR.Location = new System.Drawing.Point(338, 255);
            this.btnContR.Name = "btnContR";
            this.btnContR.Size = new System.Drawing.Size(75, 54);
            this.btnContR.TabIndex = 2;
            this.btnContR.Text = "Conta Letra R";
            this.btnContR.UseVisualStyleBackColor = true;
            this.btnContR.Click += new System.EventHandler(this.btnContR_Click);
            // 
            // btnContPar
            // 
            this.btnContPar.Location = new System.Drawing.Point(504, 255);
            this.btnContPar.Name = "btnContPar";
            this.btnContPar.Size = new System.Drawing.Size(75, 54);
            this.btnContPar.TabIndex = 3;
            this.btnContPar.Text = "Conta Pares de Letras";
            this.btnContPar.UseVisualStyleBackColor = true;
            this.btnContPar.Click += new System.EventHandler(this.btnContPar_Click);
            // 
            // btnVoltar
            // 
            this.btnVoltar.Location = new System.Drawing.Point(338, 355);
            this.btnVoltar.Name = "btnVoltar";
            this.btnVoltar.Size = new System.Drawing.Size(75, 23);
            this.btnVoltar.TabIndex = 4;
            this.btnVoltar.Text = "Voltar";
            this.btnVoltar.UseVisualStyleBackColor = true;
            this.btnVoltar.Click += new System.EventHandler(this.btnVoltar_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnVoltar);
            this.Controls.Add(this.btnContPar);
            this.Controls.Add(this.btnContR);
            this.Controls.Add(this.btnContBranco);
            this.Controls.Add(this.rchTxt1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchTxt1;
        private System.Windows.Forms.Button btnContBranco;
        private System.Windows.Forms.Button btnContR;
        private System.Windows.Forms.Button btnContPar;
        private System.Windows.Forms.Button btnVoltar;
    }
}