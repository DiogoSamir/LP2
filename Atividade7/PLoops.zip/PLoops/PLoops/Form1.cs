﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExer1_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["Form2"];

            if (fc != null)
                fc.Close();

            Form2 frm = new Form2();
            frm.Show();
        }

        private void btnExer2_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["Form3"];

            if (fc != null)
                fc.Close();

            Form3 frm = new Form3();
            frm.Show();
        }

        private void btnExer3_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["Form4"];

            if (fc != null)
                fc.Close();

            Form4 frm = new Form4();
            frm.Show();
        }

        private void btnExer4_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["Form5"];

            if (fc != null)
                fc.Close();

            Form5 frm = new Form5();
            frm.Show();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
