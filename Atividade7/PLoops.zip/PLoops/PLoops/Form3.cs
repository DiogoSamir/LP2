﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            double H = 0;
            int Calc = 0;

            Int32.TryParse(txtCalc.Text, out Calc);
            if (Calc == 0)
                MessageBox.Show("Digite apenas numeros \n maior que zero");
            else
            {
                for (double i = 1; i <= Calc; i++)
                {
                    H += 1 / i;
                }
                H = Math.Round(H, 4);
                MessageBox.Show("O Resultado de H é: " + H);
            }
        }

        private void btnVolt_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
