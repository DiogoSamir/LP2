﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void btnVerif_Click(object sender, EventArgs e)
        {
            string palindro;
            int posicao = 0;

            palindro = txtPalindro.Text.ToUpper();
            posicao = palindro.IndexOf(' ');
            while (posicao > 0)
            {
                palindro = palindro.Substring(0, posicao) +
                    palindro.Substring(posicao + 1, palindro.Length - posicao - 1);
                posicao = palindro.IndexOf(' ');
            }
            string p = palindro;
            char[] arr = p.ToCharArray();
            Array.Reverse(arr);
            p = "";
            foreach (char c in arr)
            {
                p = p + c.ToString();
            }
            if (palindro == p)
            {
                MessageBox.Show("É Palíndromo !\n" + palindro + "\n" + p);
            }
            else
                MessageBox.Show("Não é Palíndromo !\n" + palindro + "\n" + p);
        }

        private void btnVolt_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
